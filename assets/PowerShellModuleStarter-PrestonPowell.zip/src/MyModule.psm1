# Dot-source all functions in public and private folders
Get-ChildItem -Path (Join-Path $PSScriptRoot 'public/*.ps1') | ForEach-Object { . $_.FullName }
Get-ChildItem -Path (Join-Path $PSScriptRoot 'private/*.ps1') | ForEach-Object { . $_.FullName }
