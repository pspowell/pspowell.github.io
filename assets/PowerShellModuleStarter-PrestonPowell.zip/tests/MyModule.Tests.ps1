# Requires -Version 5.0
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module (Join-Path $here '..' 'src' 'MyModule.psd1') -Force

Describe "MyModule" {
    It "Says hello to Preston" {
        (Get-Greeting -Name 'Preston') | Should -Be 'Hello, Preston'
    }
}
