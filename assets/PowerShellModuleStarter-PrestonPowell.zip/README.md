# PowerShell Module Starter — Preston Powell

A ready-to-use scaffold for professional PowerShell development in VS Code with Git, PSScriptAnalyzer, Pester, and debugging preconfigured.

## Features
- PowerShell 7-first setup (works with Windows PowerShell 5.1 too)
- ScriptAnalyzer linting + auto-format
- Pester tests + test debug config
- Git/GitLens-friendly layout
- Launch configs for running scripts and tests
- Tasks for formatting and running tests

## Structure
```
src/
  MyModule.psd1
  MyModule.psm1
  public/
    Get-Greeting.ps1
  private/
tests/
  MyModule.Tests.ps1
.vscode/
  settings.json
  launch.json
  tasks.json
.editorconfig
.gitattributes
.gitignore
PSScriptAnalyzerSettings.psd1
```

## Quick start
```powershell
# Open folder in VS Code
code .

# Install dev dependencies once
pwsh -NoProfile -Command "Install-Module PSScriptAnalyzer,Pester -Scope CurrentUser -Force"

# Run tests
pwsh -NoProfile -Command "Invoke-Pester -Path tests -Output Detailed"
```

## Git setup (optional)
```powershell
git init
git add .
git commit -m "chore: initial scaffold"
git branch -M main
git remote add origin git@github.com:<you>/<repo>.git
git push -u origin main
```
