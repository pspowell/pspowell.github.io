# Bootstrap dev dependencies and git (optional)
param(
    [string]$UserName = 'Preston Powell',
    [string]$UserEmail = 'you@example.com'
)
Write-Host "Installing dev modules..." -ForegroundColor Cyan
Install-Module PSScriptAnalyzer,Pester -Scope CurrentUser -Force

Write-Host "Initializing git..." -ForegroundColor Cyan
git init
git config user.name  $UserName
git config user.email $UserEmail
git add .
git commit -m "chore: initial scaffold"
Write-Host "Done. Remember to set the remote and push if desired." -ForegroundColor Green
