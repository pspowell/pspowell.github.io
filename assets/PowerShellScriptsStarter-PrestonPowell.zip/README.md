# PowerShell Scripts Starter — Preston Powell

A clean, **scripts-only** scaffold for PowerShell development in VS Code — no module manifest. Ideal for utilities, admin scripts, and small tools.

## Features
- PowerShell 7-first setup
- ScriptAnalyzer linting + auto-format
- Pester tests with a sample
- Launch configs to run the current script
- Tasks to format code and run tests

## Structure
```
scripts/
  Get-Greeting.ps1
tests/
  Scripts.Tests.ps1
.vscode/
  settings.json
  launch.json
  tasks.json
.editorconfig
.gitattributes
.gitignore
PSScriptAnalyzerSettings.psd1
```

## Quick start
```powershell
code .
pwsh -NoProfile -Command "Install-Module PSScriptAnalyzer,Pester -Scope CurrentUser -Force"
Invoke-Pester -Path tests -Output Detailed
```
