# Requires -Version 5.0
Describe "Scripts" {
    It "Says hello to Preston" {
        $out = & (Join-Path $PSScriptRoot '..' 'scripts' 'Get-Greeting.ps1') -Name 'Preston'
        $out | Should -Be 'Hello, Preston'
    }
}
