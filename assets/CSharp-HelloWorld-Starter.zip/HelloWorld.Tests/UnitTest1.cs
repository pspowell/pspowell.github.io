using Xunit;

namespace HelloWorld.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void True_is_true() => Assert.True(true);
    }
}
