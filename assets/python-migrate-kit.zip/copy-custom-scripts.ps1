param(
    [string]$OldPython = "C:\Users\<you>\AppData\Local\Programs\Python\Python311\python.exe",
    [string]$NewPython = "C:\Users\<you>\AppData\Local\Programs\Python\Python313\python.exe"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $OldPython)) {
    Write-Error "Old Python not found at $OldPython"
    exit 1
}
if (-not (Test-Path $NewPython)) {
    Write-Error "New Python not found at $NewPython"
    exit 1
}

$oldRoot    = Split-Path $OldPython -Parent
$newRoot    = Split-Path $NewPython -Parent
$oldScripts = Join-Path $oldRoot "Scripts"
$newScripts = Join-Path $newRoot "Scripts"

if (-not (Test-Path $oldScripts)) {
    Write-Error "Old Scripts folder not found at $oldScripts"
    exit 1
}

New-Item -ItemType Directory -Path $newScripts -Force | Out-Null

Write-Host "Copying custom .py and .cmd from:"
Write-Host "  $oldScripts"
Write-Host "to:"
Write-Host "  $newScripts"

Get-ChildItem $oldScripts -Include *.py, *.cmd -File | ForEach-Object {
    Copy-Item $_.FullName -Destination $newScripts -Force
}

Write-Host "Done. Review copied scripts and remove any that you don't recognize as your own."
