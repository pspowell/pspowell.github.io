param(
    [string]$OldPython = "C:\\Users\\<you>\\AppData\\Local\\Programs\\Python\\Python311\\python.exe",
    [string]$NewPython = "C:\\Users\\<you>\\AppData\\Local\\Programs\\Python\\Python313\\python.exe"
)
...
