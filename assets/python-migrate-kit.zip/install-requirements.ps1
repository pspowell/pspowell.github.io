param(
    [string]$NewPython = "C:\\Users\\<you>\\AppData\\Local\\Programs\\Python\\Python313\\python.exe",
    [string]$RequirementsPath = "$env:TEMP\\py_requirements_old.txt"
)
...
