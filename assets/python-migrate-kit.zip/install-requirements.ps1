param(
    [string]$NewPython = "C:\Users\<you>\AppData\Local\Programs\Python\Python313\python.exe",
    [string]$RequirementsPath = "$env:TEMP\py_requirements_old.txt"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $NewPython)) {
    Write-Error "New Python not found at $NewPython"
    exit 1
}
if (-not (Test-Path $RequirementsPath)) {
    Write-Error "Requirements file not found at $RequirementsPath"
    exit 1
}

Write-Host "Upgrading pip for new Python ($NewPython)..."
& $NewPython -m pip install --upgrade pip

Write-Host "Installing packages from $RequirementsPath into new Python..."
& $NewPython -m pip install -r $RequirementsPath

Write-Host "Done."
