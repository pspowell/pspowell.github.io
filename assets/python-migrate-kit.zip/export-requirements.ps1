param(
    [string]$OldPython = "C:\\Users\\<you>\\AppData\\Local\\Programs\\Python\\Python311\\python.exe",
    [string]$OutputPath
)
...
