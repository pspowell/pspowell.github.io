param(
    [string]$OldPython = "C:\Users\<you>\AppData\Local\Programs\Python\Python311\python.exe",
    [string]$OutputPath
)

$ErrorActionPreference = "Stop"

if (-not $OutputPath) {
    $OutputPath = Join-Path $env:TEMP "py_requirements_old.txt"
}

if (-not (Test-Path $OldPython)) {
    Write-Error "Old Python not found at $OldPython"
    exit 1
}

Write-Host "Exporting packages from old Python ($OldPython) to $OutputPath"

& $OldPython -m pip list --format=freeze 2>$null |
    Where-Object {$_ -notmatch "^pip==|^setuptools==|^wheel==|^pkg-resources==|^distribute=="} |
    Set-Content -Path $OutputPath

Write-Host "Done."
