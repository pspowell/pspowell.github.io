Python Migration Kit (Windows / PowerShell)
==========================================

This kit helps you move from an old Python installation (e.g. 3.11) to a new one (e.g. 3.13)
on Windows, while keeping your installed packages and any custom scripts you added.

Files
-----
- migrate-python.ps1
  One-stop helper script. Exports packages from the old Python, installs them into the new
  Python, and can optionally copy your custom .py/.cmd scripts from the old Scripts folder.

- export-requirements.ps1
  Exports the pip package list from the old Python into a requirements-style text file.

- install-requirements.ps1
  Installs packages from a requirements-style text file into the new Python.

- copy-custom-scripts.ps1
  Copies *.py and *.cmd from the old Scripts folder to the new Scripts folder so your own
  helper scripts and launchers follow you.

Basic usage
-----------
1. Install the new Python from python.org. Make sure you know the old and new python.exe paths.

2. Run the migration helper (recommended):

   Example (PowerShell):
       Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
       .\migrate-python.ps1 `
           -OldPython "C:\Users\<you>\AppData\Local\Programs\Python\Python311\python.exe" `
           -NewPython "C:\Users\<you>\AppData\Local\Programs\Python\Python313\python.exe" `
           -CopyCustomScripts

3. After migration:
   - Update your PATH so it only points at the new Python install.
   - Verify with:
       python --version
       py -0p
   - Test your projects.
   - When satisfied, uninstall the old Python from "Add or Remove Programs".

Notes
-----
- These scripts assume "plain" python.org-style installs on Windows.
- They do not touch virtual environments; you'll typically recreate or re-point those manually.
- Review any copied scripts in the new Scripts folder to make sure they're yours and still needed.
