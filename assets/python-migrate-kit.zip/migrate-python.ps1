param(
    [string]$OldPython = "C:\Users\<you>\AppData\Local\Programs\Python\Python311\python.exe",
    [string]$NewPython = "C:\Users\<you>\AppData\Local\Programs\Python\Python313\python.exe",
    [switch]$CopyCustomScripts
)

$ErrorActionPreference = "Stop"

Write-Host "=== Python Migration Helper ===" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path $OldPython)) {
    Write-Error "Old Python not found at $OldPython"
    exit 1
}
if (-not (Test-Path $NewPython)) {
    Write-Error "New Python not found at $NewPython"
    exit 1
}

Write-Host "Old Python: $OldPython"
Write-Host "New Python: $NewPython"
Write-Host ""

# 1) Export old packages
$tempReq = Join-Path $env:TEMP "py_migrate_requirements.txt"
Write-Host "Exporting packages from old Python..."
& $OldPython -m pip list --format=freeze 2>$null |
    Where-Object {$_ -notmatch "^pip==|^setuptools==|^wheel==|^pkg-resources==|^distribute=="} |
    Set-Content -Path $tempReq

Write-Host "Requirements written to $tempReq"
Write-Host ""

# 2) Upgrade pip and install in new Python
Write-Host "Upgrading pip for new Python..."
& $NewPython -m pip install --upgrade pip

Write-Host "Installing packages into new Python (this may take a while)..."
& $NewPython -m pip install -r $tempReq

Write-Host ""
Write-Host "Package migration complete."
Write-Host ""

# 3) Optionally copy custom scripts
if ($CopyCustomScripts) {
    $oldRoot    = Split-Path $OldPython -Parent
    $newRoot    = Split-Path $NewPython -Parent
    $oldScripts = Join-Path $oldRoot "Scripts"
    $newScripts = Join-Path $newRoot "Scripts"

    if (Test-Path $oldScripts) {
        Write-Host "Copying custom .py and .cmd scripts from:"
        Write-Host "  $oldScripts"
        Write-Host "to:"
        Write-Host "  $newScripts"
        New-Item -ItemType Directory -Path $newScripts -Force | Out-Null

        # Copy only .py and .cmd (you may want to filter more aggressively)
        Get-ChildItem $oldScripts -Include *.py, *.cmd -File | ForEach-Object {
            Copy-Item $_.FullName -Destination $newScripts -Force
        }
    } else {
        Write-Host "No old Scripts folder found at $oldScripts"
    }
}

Write-Host ""
Write-Host "Migration steps completed."
Write-Host "Next steps:"
Write-Host "  - Update PATH to point to only the new Python install."
Write-Host "  - Verify with 'python --version' and 'py -0p'."
Write-Host "  - Test your projects and tools."
Write-Host "  - Then uninstall the old Python from 'Add or Remove Programs'."
